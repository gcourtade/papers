from pymol import cmd
from pymol.cgo import BEGIN, TRIANGLES, VERTEX, COLOR, ALPHA, END
import numpy as np


# ============================================================
# STORAGE
# ============================================================
#
# Each protein gets its own plane:
#
# _PLANES["ScCBM2"] = {
#     "point": ...,
#     "normal": ...
# }
#
# This means multiple proteins can be analyzed simultaneously.
# ============================================================

_PLANES = {}


# ============================================================
# HELPER FUNCTIONS
# ============================================================

def get_single_atom_coord(selection):
    """
    Return coordinates of exactly one selected atom.
    """

    model = cmd.get_model(selection)

    if len(model.atom) != 1:
        raise ValueError(
            f"Selection '{selection}' contains {len(model.atom)} atoms. "
            "Please select exactly one atom."
        )

    return np.array(model.atom[0].coord, dtype=float)


def convex_hull_2d(points):
    """
    Calculate a 2D convex hull using the monotonic-chain algorithm.

    No scipy required.
    """

    points = sorted(set(map(tuple, points)))

    if len(points) <= 1:
        return np.array(points)

    def cross(o, a, b):
        return (
            (a[0] - o[0]) * (b[1] - o[1])
            - (a[1] - o[1]) * (b[0] - o[0])
        )

    # Lower hull
    lower = []

    for p in points:

        while (
            len(lower) >= 2
            and cross(lower[-2], lower[-1], p) <= 0
        ):
            lower.pop()

        lower.append(p)

    # Upper hull
    upper = []

    for p in reversed(points):

        while (
            len(upper) >= 2
            and cross(upper[-2], upper[-1], p) <= 0
        ):
            upper.pop()

        upper.append(p)

    return np.array(lower[:-1] + upper[:-1])


def polygon_area(points):
    """
    Calculate area of a 2D polygon.
    """

    x = points[:, 0]
    y = points[:, 1]

    return 0.5 * abs(
        np.dot(x, np.roll(y, 1))
        - np.dot(y, np.roll(x, 1))
    )


# ============================================================
# MAKE PLANE
# ============================================================

def make_plane(
    protein,
    point1,
    point2,
    point3,
    size=20.0
):
    """
    Create and store a binding plane for a protein.

    Usage:

        make_plane ScCBM2, p1, p2, p3

    or:

        make_plane ScCBM2, p1, p2, p3, 30

    Creates:

        ScCBM2_binding_plane
    """

    global _PLANES

    # --------------------------------------------------------
    # Get coordinates
    # --------------------------------------------------------

    p1 = get_single_atom_coord(point1)
    p2 = get_single_atom_coord(point2)
    p3 = get_single_atom_coord(point3)

    # --------------------------------------------------------
    # Calculate plane
    # --------------------------------------------------------

    v1 = p2 - p1
    v2 = p3 - p1

    normal = np.cross(v1, v2)

    norm = np.linalg.norm(normal)

    if norm < 1e-8:
        raise ValueError(
            "The three selected atoms are collinear "
            "and cannot define a plane."
        )

    normal /= norm

    center = (p1 + p2 + p3) / 3.0

    # --------------------------------------------------------
    # Store plane information under protein name
    # --------------------------------------------------------

    _PLANES[protein] = {
        "point": center,
        "normal": normal
    }

    # --------------------------------------------------------
    # Construct axes lying in plane
    # --------------------------------------------------------

    u = v1 / np.linalg.norm(v1)

    v = np.cross(normal, u)
    v /= np.linalg.norm(v)

    size = float(size)

    # Four corners
    a = center - size*u - size*v
    b = center + size*u - size*v
    c = center + size*u + size*v
    d = center - size*u + size*v

    # --------------------------------------------------------
    # Create CGO plane
    # --------------------------------------------------------

    plane_name = f"{protein}_binding_plane"

    obj = [
        BEGIN, TRIANGLES,

        COLOR, 0.5, 0.5, 0.5,
        ALPHA, 0.35,

        VERTEX, *a,
        VERTEX, *b,
        VERTEX, *c,

        VERTEX, *a,
        VERTEX, *c,
        VERTEX, *d,

        END
    ]

    cmd.delete(plane_name)
    cmd.load_cgo(obj, plane_name)

    # --------------------------------------------------------
    # Output
    # --------------------------------------------------------

    print("")
    print("=" * 50)
    print(f"Binding plane created for: {protein}")
    print("=" * 50)

    print("Point 1:", p1)
    print("Point 2:", p2)
    print("Point 3:", p3)

    print("")
    print("Plane center:", center)
    print("Plane normal:", normal)

    print("")
    print(f"Created object: {plane_name}")
    print("")


# ============================================================
# SELECT SURFACE ATOMS CLOSE TO PLANE
# ============================================================

def select_plane_surface(
    protein,
    distance=4.0,
    exposure_cutoff=2.5
):
    """
    Select surface-exposed protein atoms within a given
    perpendicular distance of the stored binding plane.

    Usage:

        select_plane_surface ScCBM2, 4

    Creates:

        ScCBM2_plane_surface
    """

    global _PLANES

    if protein not in _PLANES:
        raise RuntimeError(
            f"No plane stored for '{protein}'. "
            f"Run 'make_plane {protein}, ...' first."
        )

    plane_point = _PLANES[protein]["point"]
    plane_normal = _PLANES[protein]["normal"]

    distance = float(distance)
    exposure_cutoff = float(exposure_cutoff)

    selection_name = f"{protein}_plane_surface"

    # Restrict calculation to protein atoms in this object
    protein_selection = f"({protein}) and polymer.protein"

    # --------------------------------------------------------
    # Make temporary copy
    # --------------------------------------------------------

    temp = f"_surface_temp_{protein}"

    cmd.delete(temp)

    cmd.create(
        temp,
        protein_selection
    )

    # --------------------------------------------------------
    # Calculate per-atom SASA
    # --------------------------------------------------------

    cmd.set("dot_solvent", 1)
    cmd.set("dot_density", 4)

    # load_b=1 stores atomic SASA in B-factor
    cmd.get_area(
        temp,
        load_b=1
    )

    model = cmd.get_model(temp)

    selected_atoms = []

    # --------------------------------------------------------
    # Check each atom
    # --------------------------------------------------------

    for atom in model.atom:

        xyz = np.array(
            atom.coord,
            dtype=float
        )

        # Shortest/perpendicular distance to plane
        d = abs(
            np.dot(
                xyz - plane_point,
                plane_normal
            )
        )

        # SASA stored in B-factor
        exposed_area = atom.b

        if (
            d <= distance
            and exposed_area >= exposure_cutoff
        ):

            selected_atoms.append(atom)

    # --------------------------------------------------------
    # Transfer selection back to original protein
    # --------------------------------------------------------

    selections = []

    for atom in selected_atoms:

        atom_selection = (
            f"({protein_selection}) and "
            f"chain {atom.chain} and "
            f"resi {atom.resi} and "
            f"name {atom.name}"
        )

        selections.append(atom_selection)

    if selections:

        cmd.select(
            selection_name,
            " or ".join(selections)
        )

    else:

        cmd.select(
            selection_name,
            "none"
        )

    # Remove temporary object
    cmd.delete(temp)

    # --------------------------------------------------------
    # Output
    # --------------------------------------------------------

    n_atoms = cmd.count_atoms(selection_name)

    print("")
    print("=" * 50)
    print(f"Plane surface selection: {protein}")
    print("=" * 50)

    print(f"Distance cutoff:   {distance:.2f} Å")
    print(f"Exposure cutoff:   {exposure_cutoff:.2f} Å²")
    print(f"Selected atoms:    {n_atoms}")

    print("")
    print(f"Created selection: {selection_name}")
    print("")


# ============================================================
# CALCULATE + DISPLAY FOOTPRINT
# ============================================================

def plane_area(
    protein,
    offset=0.2
):
    """
    Project the selected plane-surface atoms onto the stored
    plane and calculate their 2D convex-hull area.

    Also displays the convex hull as a CGO object.

    Usage:

        plane_area ScCBM2

    Uses:

        ScCBM2_plane_surface

    Creates:

        ScCBM2_binding_footprint
    """

    global _PLANES

    if protein not in _PLANES:
        raise RuntimeError(
            f"No plane stored for '{protein}'."
        )

    plane_point = _PLANES[protein]["point"]
    plane_normal = _PLANES[protein]["normal"]

    selection = f"{protein}_plane_surface"

    footprint_name = f"{protein}_binding_footprint"

    # --------------------------------------------------------
    # Get selected atoms
    # --------------------------------------------------------

    model = cmd.get_model(selection)

    if len(model.atom) < 3:
        raise ValueError(
            f"Selection '{selection}' contains fewer than "
            "three atoms."
        )

    xyz = np.array(
        [atom.coord for atom in model.atom],
        dtype=float
    )

    # --------------------------------------------------------
    # Define 2D coordinate system in plane
    # --------------------------------------------------------

    n = plane_normal

    # Pick reference direction not parallel to normal
    if abs(n[0]) < 0.9:

        reference = np.array(
            [1.0, 0.0, 0.0]
        )

    else:

        reference = np.array(
            [0.0, 1.0, 0.0]
        )

    u = np.cross(
        n,
        reference
    )

    u /= np.linalg.norm(u)

    v = np.cross(
        n,
        u
    )

    v /= np.linalg.norm(v)

    # --------------------------------------------------------
    # Project atoms onto plane
    # --------------------------------------------------------

    relative = xyz - plane_point

    x = relative @ u
    y = relative @ v

    points_2d = np.column_stack(
        (x, y)
    )

    # --------------------------------------------------------
    # Convex hull
    # --------------------------------------------------------

    hull = convex_hull_2d(
        points_2d
    )

    if len(hull) < 3:
        raise ValueError(
            "Projected atoms do not form a valid 2D area."
        )

    # --------------------------------------------------------
    # Calculate area
    # --------------------------------------------------------

    area_A2 = polygon_area(hull)

    area_nm2 = area_A2 / 100.0

    # --------------------------------------------------------
    # Convert hull vertices back to 3D
    # --------------------------------------------------------

    hull_3d = []

    for xh, yh in hull:

        point = (
            plane_point
            + xh * u
            + yh * v
            + float(offset) * n
        )

        hull_3d.append(point)

    # --------------------------------------------------------
    # Create filled CGO polygon
    # --------------------------------------------------------

    obj = [
        BEGIN, TRIANGLES,

        COLOR, 0.2, 0.7, 0.9,
        ALPHA, 0.5
    ]

    # Triangle fan
    for i in range(
        1,
        len(hull_3d) - 1
    ):

        obj.extend([
            VERTEX,
            *hull_3d[0],

            VERTEX,
            *hull_3d[i],

            VERTEX,
            *hull_3d[i + 1]
        ])

    obj.append(END)

    # --------------------------------------------------------
    # Create footprint object
    # --------------------------------------------------------

    cmd.delete(footprint_name)

    cmd.load_cgo(
        obj,
        footprint_name
    )

    # --------------------------------------------------------
    # Output
    # --------------------------------------------------------

    print("")
    print("=" * 50)
    print(f"Binding footprint: {protein}")
    print("=" * 50)

    print(f"Surface selection: {selection}")
    print(f"Selected atoms:    {len(model.atom)}")
    print(f"Hull vertices:     {len(hull)}")

    print("")
    print(f"Area:              {area_A2:.2f} Å²")
    print(f"Area:              {area_nm2:.3f} nm²")

    print("")
    print(f"Created object:    {footprint_name}")
    print("")

    return area_A2


# ============================================================
# OPTIONAL: RUN ALL STEPS AFTER PLANE HAS BEEN DEFINED
# ============================================================

def analyze_plane(
    protein,
    distance=4.0,
    exposure_cutoff=2.5
):
    """
    Run surface selection and footprint calculation
    for an already-defined plane.

    Usage:

        analyze_plane ScCBM2

    or:

        analyze_plane ScCBM2, 4, 2.5
    """

    select_plane_surface(
        protein,
        distance,
        exposure_cutoff
    )

    return plane_area(protein)


# ============================================================
# REGISTER PYMOL COMMANDS
# ============================================================

cmd.extend(
    "make_plane",
    make_plane
)

cmd.extend(
    "select_plane_surface",
    select_plane_surface
)

cmd.extend(
    "plane_area",
    plane_area
)

cmd.extend(
    "analyze_plane",
    analyze_plane
)