from pymol import cmd
from pymol.cgo import BEGIN, TRIANGLES, VERTEX, COLOR, ALPHA, END
import numpy as np


# ============================================================
# VAN DER WAALS RADII (Å)
# ============================================================

VDW_RADII = {
    "H": 1.20,
    "C": 1.70,
    "N": 1.55,
    "O": 1.52,
    "S": 1.80,
    "P": 1.80,
}


def get_single_atom_coord(selection):
    """Return coordinates of exactly one selected atom."""

    model = cmd.get_model(selection)

    if len(model.atom) != 1:
        raise ValueError(
            f"Selection '{selection}' contains {len(model.atom)} atoms. "
            "Please select exactly one atom."
        )

    return np.array(model.atom[0].coord, dtype=float)


# ============================================================
# MAIN FUNCTION
# ============================================================

def protein_footprint(
    protein,
    point1,
    point2,
    point3,
    grid=0.15,
    offset=0.3
):
    """
    Calculate the projected footprint of an entire protein
    onto a plane defined by three atoms.

    Each atom is projected onto the plane and represented as
    a disk using its van der Waals radius. The union of these
    disks gives the projected protein footprint.

    Usage
    -----
    protein_footprint ScCBM2, p1, p2, p3

    Optional grid spacing:
    protein_footprint ScCBM2, p1, p2, p3, 0.10

    Creates:
        ScCBM2_protein_footprint

    Parameters
    ----------
    protein
        Name of protein object.

    point1, point2, point3
        Three selections, each containing exactly one atom,
        defining the projection plane.

    grid
        Grid spacing in Å. Smaller = more accurate but slower.
        Default = 0.15 Å.

    offset
        Visual offset from the plane in Å.
    """

    grid = float(grid)
    offset = float(offset)

    if grid <= 0:
        raise ValueError("Grid spacing must be greater than zero.")

    # ========================================================
    # DEFINE PLANE
    # ========================================================

    p1 = get_single_atom_coord(point1)
    p2 = get_single_atom_coord(point2)
    p3 = get_single_atom_coord(point3)

    v1 = p2 - p1
    v2 = p3 - p1

    normal = np.cross(v1, v2)

    norm = np.linalg.norm(normal)

    if norm < 1e-8:
        raise ValueError(
            "The three selected atoms are collinear and "
            "cannot define a plane."
        )

    normal /= norm

    plane_point = (p1 + p2 + p3) / 3.0

    # ========================================================
    # DEFINE TWO AXES WITHIN THE PLANE
    # ========================================================

    u = v1 / np.linalg.norm(v1)

    v = np.cross(normal, u)
    v /= np.linalg.norm(v)

    # ========================================================
    # GET PROTEIN ATOMS
    # ========================================================

    protein_selection = f"({protein}) and polymer.protein"

    model = cmd.get_model(protein_selection)

    if len(model.atom) == 0:
        raise ValueError(
            f"No protein atoms found for '{protein}'."
        )

    coords = []
    radii = []

    for atom in model.atom:

        coords.append(
            np.array(atom.coord, dtype=float)
        )

        # Try PyMOL's own VDW radius first
        radius = getattr(atom, "vdw", 0.0)

        if radius is None or radius <= 0:
            element = atom.symbol.upper()

            radius = VDW_RADII.get(
                element,
                1.70
            )

        radii.append(radius)

    coords = np.array(coords)
    radii = np.array(radii)

    # ========================================================
    # PROJECT ATOM CENTERS ONTO PLANE
    # ========================================================

    relative = coords - plane_point

    x_atoms = relative @ u
    y_atoms = relative @ v

    # ========================================================
    # DEFINE 2D GRID
    # ========================================================

    margin = np.max(radii) + grid

    xmin = np.min(x_atoms - radii) - margin
    xmax = np.max(x_atoms + radii) + margin

    ymin = np.min(y_atoms - radii) - margin
    ymax = np.max(y_atoms + radii) + margin

    xs = np.arange(
        xmin,
        xmax + grid,
        grid
    )

    ys = np.arange(
        ymin,
        ymax + grid,
        grid
    )

    # occupied[y, x]
    occupied = np.zeros(
        (len(ys), len(xs)),
        dtype=bool
    )

    # ========================================================
    # FILL PROJECTED ATOMIC DISKS
    # ========================================================

    for xa, ya, radius in zip(
        x_atoms,
        y_atoms,
        radii
    ):

        # Restrict calculations to local region around atom
        ix_min = max(
            0,
            int(np.floor((xa - radius - xmin) / grid))
        )

        ix_max = min(
            len(xs) - 1,
            int(np.ceil((xa + radius - xmin) / grid))
        )

        iy_min = max(
            0,
            int(np.floor((ya - radius - ymin) / grid))
        )

        iy_max = min(
            len(ys) - 1,
            int(np.ceil((ya + radius - ymin) / grid))
        )

        local_x = xs[ix_min:ix_max + 1]
        local_y = ys[iy_min:iy_max + 1]

        X, Y = np.meshgrid(
            local_x,
            local_y
        )

        inside = (
            (X - xa)**2
            + (Y - ya)**2
            <= radius**2
        )

        occupied[
            iy_min:iy_max + 1,
            ix_min:ix_max + 1
        ] |= inside

    # ========================================================
    # CALCULATE AREA
    # ========================================================

    n_occupied = np.count_nonzero(occupied)

    area_A2 = n_occupied * grid**2

    area_nm2 = area_A2 / 100.0

    # ========================================================
    # CREATE VISUAL FOOTPRINT
    # ========================================================

    footprint_name = f"{protein}_protein_footprint"

    cmd.delete(footprint_name)

    obj = [
        BEGIN,
        TRIANGLES,

        COLOR,
        0.9, 0.4, 0.2,

        ALPHA,
        0.45
    ]

    # To keep the CGO object reasonably small, make a square
    # for every occupied grid cell.

    half = grid / 2.0

    occupied_indices = np.argwhere(occupied)

    for iy, ix in occupied_indices:

        x = xs[ix]
        y = ys[iy]

        # Four corners in 2D
        corners_2d = [
            (x - half, y - half),
            (x + half, y - half),
            (x + half, y + half),
            (x - half, y + half)
        ]

        corners_3d = []

        for cx, cy in corners_2d:

            point = (
                plane_point
                + cx * u
                + cy * v
                + offset * normal
            )

            corners_3d.append(point)

        a, b, c, d = corners_3d

        # Two triangles forming square
        obj.extend([
            VERTEX, *a,
            VERTEX, *b,
            VERTEX, *c,

            VERTEX, *a,
            VERTEX, *c,
            VERTEX, *d
        ])

    obj.append(END)

    cmd.load_cgo(
        obj,
        footprint_name
    )

    # ========================================================
    # OUTPUT
    # ========================================================

    print("")
    print("=" * 55)
    print(f"Whole-protein projected footprint: {protein}")
    print("=" * 55)

    print(f"Protein atoms:       {len(model.atom)}")
    print(f"Grid spacing:        {grid:.3f} Å")
    print(f"Occupied grid cells: {n_occupied}")

    print("")
    print(f"Projected area:      {area_A2:.2f} Å²")
    print(f"Projected area:      {area_nm2:.3f} nm²")

    print("")
    print(f"Created object:      {footprint_name}")
    print("")

    return area_A2


# ============================================================
# REGISTER PYMOL COMMAND
# ============================================================

cmd.extend(
    "protein_footprint",
    protein_footprint
)