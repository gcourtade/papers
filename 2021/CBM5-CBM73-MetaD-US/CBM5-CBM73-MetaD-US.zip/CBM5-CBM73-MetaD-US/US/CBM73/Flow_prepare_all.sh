#!/bin/bash

gmx=/groups/sbinlab/wyong/usr/local/GMX514/bin/gmx_mpi_plumed
export GMX_ALLOW_CPT_MISMATCH=1
export PLUMED_USE_LEPTON=yes
export PLUMED_KERNEL="/groups/sbinlab/wyong/usr/local/PLUMED250dev_PathCV/lib/libplumedKernel.so"
export LD_LIBRARY_PATH="/groups/sbinlab/wyong/usr/local/PLUMED250dev_PathCV/lib":$LD_LIBRARY_PATH

rm metadata.dat
rm *tpr

top=cbm73-all.top
FC=100.0

dist=(
  4.4 
  4.2 
  4.0 
  3.8 
  3.6 
  3.4 
  3.2
  3.0
  2.8 
  2.6 
  2.4 
  2.2
  2.0
  1.8
  1.6
  1.4
  1.2
  1.0
  0.8
  0.6
  0.4
  0.2
  0.0
)

grofiles=(
   924
   924
   925
   925
   925
   926
   926
   926
   926
   926
   926
   926
   926
   926
   927
   927
   927
   927
   930
   931
   931
   931
   931
)
for i in ${!dist[*]};
do
gro=frame${grofiles[$i]}.gro
AT=${dist[$i]}

echo "COLVAR${i} ${AT} ${FC}" >> metadata.dat

cat <<EOF >plumed${i}.dat
WHOLEMOLECULES ENTITY0=721-882

a1: CENTER ATOMS=793-797 
a2: CENTER ATOMS=809-812 
a3: CENTER ATOMS=828-832 
achi: CENTER ATOMS=1-720 

p1: POSITION ATOM=a1 NOPBC
p2: POSITION ATOM=a2 NOPBC
p3: POSITION ATOM=a3 NOPBC
pchi: POSITION ATOM=achi NOPBC

distx: MATHEVAL ARG=p1.x,p2.x,p3.x,pchi.x VAR=a,b,c,y FUNC=((y-a)^2+(y-b)^2+(y-c)^2)^0.5 PERIODIC=NO

restraint-bnd: RESTRAINT ARG=distx KAPPA=${FC} AT=${AT}

PRINT ARG=distx,restraint-bnd.bias STRIDE=5000 FILE=COLVAR${i}

EOF

cat <<EOF >submit${i}.sh

gmx=/groups/sbinlab/wyong/usr/local/GMX514/bin/gmx_mpi_plumed
export GMX_ALLOW_CPT_MISMATCH=1
export PLUMED_USE_LEPTON=yes
export PLUMED_KERNEL="/groups/sbinlab/wyong/usr/local/PLUMED250dev_PathCV/lib/libplumedKernel.so"
export LD_LIBRARY_PATH="/groups/sbinlab/wyong/usr/local/PLUMED250dev_PathCV/lib":$LD_LIBRARY_PATH

${gmx} grompp -f minimization.mdp -p ${top} -c ${gro} -o min_${i}.tpr -maxwarn 2
${gmx} mdrun -deffnm min_${i} -v -ntomp 1

${gmx} grompp -f relax.mdp -p ${top} -c min_${i}.gro -o md1_${i}.tpr -n index.ndx -maxwarn 2
${gmx} mdrun -deffnm md1_${i} -v -ntomp 4

${gmx} grompp -f md.mdp -p ${top} -c md1_${i}.gro -o md_${i}.tpr -n index.ndx -maxwarn 2
${gmx} mdrun -deffnm md_${i} -plumed plumed${i}.dat -nsteps 5000000 -ntomp 4 -v

EOF


done

rm \#*

exit
