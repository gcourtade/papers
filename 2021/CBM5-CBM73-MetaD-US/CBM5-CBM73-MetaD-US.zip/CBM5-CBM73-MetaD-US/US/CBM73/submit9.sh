
gmx=/groups/sbinlab/wyong/usr/local/GMX514/bin/gmx_mpi_plumed
export GMX_ALLOW_CPT_MISMATCH=1
export PLUMED_USE_LEPTON=yes
export PLUMED_KERNEL="/groups/sbinlab/wyong/usr/local/PLUMED250dev_PathCV/lib/libplumedKernel.so"
export LD_LIBRARY_PATH="/groups/sbinlab/wyong/usr/local/PLUMED250dev_PathCV/lib":/groups/sbinlab/wyong/usr/local/PLUMED250dev_PathCV/lib:

/groups/sbinlab/wyong/usr/local/GMX514/bin/gmx_mpi_plumed grompp -f minimization.mdp -p cbm73-all.top -c frame926.gro -o min_9.tpr -maxwarn 2
/groups/sbinlab/wyong/usr/local/GMX514/bin/gmx_mpi_plumed mdrun -deffnm min_9 -v -ntomp 1

/groups/sbinlab/wyong/usr/local/GMX514/bin/gmx_mpi_plumed grompp -f relax.mdp -p cbm73-all.top -c min_9.gro -o md1_9.tpr -n index.ndx -maxwarn 2
/groups/sbinlab/wyong/usr/local/GMX514/bin/gmx_mpi_plumed mdrun -deffnm md1_9 -v -ntomp 4

/groups/sbinlab/wyong/usr/local/GMX514/bin/gmx_mpi_plumed grompp -f md.mdp -p cbm73-all.top -c md1_9.gro -o md_9.tpr -n index.ndx -maxwarn 2
/groups/sbinlab/wyong/usr/local/GMX514/bin/gmx_mpi_plumed mdrun -deffnm md_9 -plumed plumed9.dat -nsteps 5000000 -ntomp 4 -v

