
gmx=/groups/sbinlab/wyong/usr/local/GMX514/bin/gmx_mpi_plumed
export GMX_ALLOW_CPT_MISMATCH=1
export PLUMED_USE_LEPTON=yes
export PLUMED_KERNEL="/groups/sbinlab/wyong/usr/local/PLUMED250dev_PathCV/lib/libplumedKernel.so"
export LD_LIBRARY_PATH="/groups/sbinlab/wyong/usr/local/PLUMED250dev_PathCV/lib":/groups/sbinlab/wyong/usr/local/PLUMED250dev_PathCV/lib:

/groups/sbinlab/wyong/usr/local/GMX514/bin/gmx_mpi_plumed grompp -f minimization.mdp -p cbm73-all.top -c frame930.gro -o min_18.tpr -maxwarn 2
/groups/sbinlab/wyong/usr/local/GMX514/bin/gmx_mpi_plumed mdrun -deffnm min_18 -v -ntomp 1

/groups/sbinlab/wyong/usr/local/GMX514/bin/gmx_mpi_plumed grompp -f relax.mdp -p cbm73-all.top -c min_18.gro -o md1_18.tpr -n index.ndx -maxwarn 2
/groups/sbinlab/wyong/usr/local/GMX514/bin/gmx_mpi_plumed mdrun -deffnm md1_18 -v -ntomp 4

/groups/sbinlab/wyong/usr/local/GMX514/bin/gmx_mpi_plumed grompp -f md.mdp -p cbm73-all.top -c md1_18.gro -o md_18.tpr -n index.ndx -maxwarn 2
/groups/sbinlab/wyong/usr/local/GMX514/bin/gmx_mpi_plumed mdrun -deffnm md_18 -plumed plumed18.dat -nsteps 5000000 -ntomp 4 -v

