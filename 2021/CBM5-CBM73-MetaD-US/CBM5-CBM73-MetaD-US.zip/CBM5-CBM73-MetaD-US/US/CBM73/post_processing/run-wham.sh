#!/bin/bash

wham=/groups/sbinlab/courtade/software/wham/wham/wham

cp ../COLVAR* .
cp ../metadata.dat .

$wham 0.0 4.4 100 0.001 300 0 metadata.dat output.dat 500 1305


rm \#*
rm bck*
