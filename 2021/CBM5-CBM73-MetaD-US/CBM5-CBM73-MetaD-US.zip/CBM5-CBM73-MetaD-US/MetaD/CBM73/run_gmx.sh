
#!/bin/sh
# 06.04.20
#

gmx=/groups/sbinlab/wyong/usr/local/GMX514/bin/gmx_mpi_plumed
export GMX_ALLOW_CPT_MISMATCH=1
export PLUMED_USE_LEPTON=yes
export PLUMED_KERNEL="/groups/sbinlab/wyong/usr/local/PLUMED250dev_PathCV/lib/libplumedKernel.so"
export LD_LIBRARY_PATH="/groups/sbinlab/wyong/usr/local/PLUMED250dev_PathCV/lib":$LD_LIBRARY_PATH

top=complex-CBM73_SOL_IONS.top
gro=complex-CBM73_SOL_IONS.gro

#============
# minimization
$gmx grompp -f minimization.mdp -p $top -c $gro -o min.tpr -pp all.top -maxwarn 2
$gmx mdrun -deffnm min -v -ntomp 1

#============
# relaxation
$gmx grompp -f relax.mdp -p all.top -c min.gro -o md1.tpr -n index.ndx -maxwarn 2
$gmx mdrun -deffnm md1 -v -ntomp 8

#============
# production
$gmx grompp -f md.mdp -p all.top -c md1.gro -o md2.tpr -n index.ndx -maxwarn 2
$gmx mdrun -deffnm md2 -v -plumed plumed.dat -ntomp 8
