#!/bin/sh
# 18.05.21

gmx=/groups/sbinlab/wyong/usr/local/GMX2018.2/bin/gmx_mpi_plumed
export GMX_ALLOW_CPT_MISMATCH=1
export PLUMED_USE_LEPTON=yes
export PLUMED_KERNEL="/groups/sbinlab/wyong/usr/local/PLUMED250dev_PathCV/lib/libplumedKernel.so"
export LD_LIBRARY_PATH="/groups/sbinlab/wyong/usr/local/PLUMED250dev_PathCV/lib":$LD_LIBRARY_PATH
plumed=/groups/sbinlab/wyong/usr/local/PLUMED250dev_PathCV/bin/plumed

$gmx trjcat -f ../md2*xtc  -o md_cat.xtc
echo 16 | $gmx trjconv -f md_cat.xtc -s ../md2.tpr -o md_comp.xtc -n ../index.ndx
echo 16 | $gmx trjconv -f ../md1.gro -s ../md2.tpr -o md_comp.gro -n ../index.ndx
rm md_cat.xtc

cp ../HILLS .
cp ../COLVAR .

# calculate weights
$plumed driver --mf_xtc md_comp.xtc --plumed calc-weights.dat --timestep 0.02 --trajectory-stride 50000

# calculate coordination per amino acid
$plumed driver --mf_xtc md_comp.xtc --plumed coordination-groups.dat --timestep 0.02 --trajectory-stride 50000

# calculate block errors for coordination per amino acid
python3 ../../../scripts/calc_block_errors.py

# calculate c(t)
rm -r FES_stride
mkdir FES_stride
$plumed sum_hills --hills HILLS --outfile FES_stride/fes- --kt 2.5 --mintozero --stride 1000
n=$(ls FES_stride/* | wc -l)
python2 ../../../scripts/reweight_2_GC.py -bsf 50.0 -kt 2.5 -fpref FES_stride/fes- -nf ${n} -fcol 3 -colvar COLVAR -biascol 4 -rewcol 2 3
