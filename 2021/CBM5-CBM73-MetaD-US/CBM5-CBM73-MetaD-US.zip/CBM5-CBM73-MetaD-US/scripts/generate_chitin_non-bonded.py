#
# This script generates the non-bonded interactions for the new chitin beads, to be added to martini_v3.0.4.itp
# 'non-bonded.xlsx' is taken fron the SI of https://link.springer.com/article/10.1007%2Fs00894-015-2670-9#Sec14
# add the following lines at the end of  [ atomtypes ]
#	;chitin beads
#	BC1 72.0 0.000 A 0.0 0.0
#	PC1 72.0 0.000 A 0.0 0.0
#	TH1 54.0 0.000 A 0.0 0.0
#	BC2 72.0 0.000 A 0.0 0.0
#	PC2 72.0 0.000 A 0.0 0.0
#	TH2 54.0 0.000 A 0.0 0.0
#
# Run the script and paste the whole output at the end of  [ nonbond_params ]
#
# G. Courtade - 26.03.20
#

import pandas as pd
import xlrd


inputfile = 'martini_v3.0.4.itp'
outputfile = 'martini_v3.0.4_chitin.itp'

df = pd.read_excel('non-bonded.xlsx')


atomtypes = [';chitin beads\n', 'BC1 72.0 0.000 A 0.0 0.0\n', 'PC1 72.0 0.000 A 0.0 0.0\n', 'TH1 54.0 0.000 A 0.0 0.0\n',
			 'BC2 72.0 0.000 A 0.0 0.0\n', 'PC2 72.0 0.000 A 0.0 0.0\n', 'TH2 54.0 0.000 A 0.0 0.0\n', '\n']

namedic = {
	'T1': 'TC1',
	'T2': 'TC2',
	'B1': 'BC1',
	'B2': 'BC2',
	'P1': 'PC1',
	'P2': 'PC2',
}

nlines = []

with open(inputfile, 'r') as f:
	lines = f.readlines()
go = False
for line in lines:
	nlines.append(line)
	if go:
		lsplit = line.split()
		if lsplit[0] == 'P2':
			for i in range(1, 2+1):
				nlines.append('PC{} {} {} {}\n'.format(
					i, lsplit[1], lsplit[2], lsplit[3], lsplit[4]))
				nlines.append('BC{} {} {} {}\n'.format(
					i, lsplit[1], lsplit[2], lsplit[3], lsplit[4]))
		elif lsplit[1] == 'P2' and lsplit[0] != lsplit[1]:
			for i in range(1, 2+1):
				nlines.append('{} PC{} {} {} {}\n'.format(
					lsplit[0], i, lsplit[2], lsplit[3], lsplit[4]))
				nlines.append('{} BC{} {} {} {}\n'.format(
					lsplit[0], i, lsplit[2], lsplit[3], lsplit[4]))
		elif lsplit[0] == 'SP1':
			for i in range(1, 2+1):
				nlines.append('TH{} {} {} {}\n'.format(
					i, lsplit[1], lsplit[2], lsplit[3], lsplit[4]))
		elif lsplit[1] == 'SP1' and lsplit[0] != lsplit[1]:
			for i in range(1, 2+1):
				nlines.append('{} TH{} {} {} {}\n'.format(
					lsplit[0], i, lsplit[2], lsplit[3], lsplit[4]))
	if '[ nonbond_params ]' in line:
		go = True
		idx = lines.index(line)
		for a in atomtypes:
			idx += 1
			nlines.insert(idx-1, a)
j = 1
for i in range(len(df['Type'].values)):
	for item in df.columns[1:]:
		if (item[-1] == '1' or item[-1] == '2') and (df['Type'].values[i][-1] == '1' or df['Type'].values[i][-1] == '2'):
			element = df.at[i, item]
			if (str(element)[-1] != '*') and (str(element) != 'nan'):
				nlines.append('{} {} {} {} {:1.4f}\n'.format(
					namedic[df['Type'].values[i]], namedic[item], 1, '4.700000e-01', float(element)*4.18))
			elif str(element)[-1] == '*':
				element1 = float(str(element)[:-1])
				nlines.append('{} {} {} {} {:1.4f}\n'.format(
					namedic[df['Type'].values[i]], namedic[item], 1, '6.500000e-01', float(element1)*4.18))
			j += 1

with open(outputfile, 'w') as f:
	for n in nlines:
		f.write(n)
