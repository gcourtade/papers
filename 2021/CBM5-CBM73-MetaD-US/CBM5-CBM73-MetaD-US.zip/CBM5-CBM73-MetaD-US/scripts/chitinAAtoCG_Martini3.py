# This script reads a chitin structure generated using Chimera from the alpha-chitin unit cell (https://pubs.acs.org/doi/10.1021/bm801251e)
# and generates coarse-grained coordinates for use with the Martini3 force-field
#
# G. Courtade - 06.08.19

import numpy as np
from itertools import cycle
import collections
filename = 'alpha-chitin.pdb'
outfile = 'chitin_CG_M3.pdb'



with open(filename, 'r') as f:
    lines = f.readlines()

beaddic = {}
coorddic = {}
def make_ichains():
    starti = 239
    curri = starti
    beadsi = cycle([
        ['T1','P1','B1'],
        ['T2','P2','B2'],
        ['T1','P3','B1'],
        ['T2','P4','B2']
        ])
    operi = cycle([1,-25])
    chainsi = 1
    unitsi = 1

    go = True
    while go:
        if unitsi > 20:
            chainsi +=1
            unitsi = 1
            starti +=  -4
            curri = starti
        if chainsi > 6:
            go = False
            break
        beaddic[curri] = next(beadsi)
        curri += next(operi)
        unitsi += 1
        
def make_jchains():
    startj1 = 18
    startj2 = 237

    currj1 = startj1
    currj2 = startj2

    beadsj = cycle([
        ['T4','P4','B4'],
        ['T3','P3','B3'],
        ['T4','P2','B4'],
        ['T3','P1','B3']
        ])
    def create_operj():
        return cycle([-3,-21])
    operj = create_operj()
    chainsj = 1
    unitsj = 1

    go = True
    while go:
        if unitsj > 20:
            chainsj += 1
            unitsj = 1

            startj1 +=  -4
            currj1 = startj1

            startj2 +=  -4
            currj2 = startj2
            operj = create_operj()
        if chainsj > 5:
            go = False
            break
        if unitsj == 1:
            beaddic[currj1] = next(beadsj)
            unitsj += 1       

        else:
            beaddic[currj2] = next(beadsj)
            currj2 += next(operj)
            unitsj += 1

def make_more_jchains():
    startj = 217
    currj = startj
    beadsj = cycle([
        ['T4','P4','B4'],
        ['T3','P3','B3'],
        ['T4','P2','B4'],
        ['T3','P1','B3']
        ])
    operj = cycle([21,-45])
    unitsj = 1

    go = True
    while go:
        if unitsj > 20:
            go = False
            break
        beaddic[currj] = next(beadsj)
        currj += next(operj)
        unitsj += 1
 


def make_corrddic():
    atomdic = {
        0:['CAG','CAN','HAN','OAM'], # T
        1:['NAF','CAE','CAH','CAJ','CAD','HAF','OAA','HAE','HAH','HAI','HAJ','HAD','OAI'], # P
        2:['CAB','CAK','OAC','OAL','HAB','HAK','HAL'] # B
        }
    coords = [[],[],[]]
    for line in lines:
        if line.startswith('ATOM'):
            lsplit = line.split()
            resnr = int(lsplit[5])
            atom = lsplit[2]
            x = float(lsplit[6])
            y = float(lsplit[7])
            z = float(lsplit[8])
            for a in atomdic:
                if atom in atomdic[a]:
                    coords[a].append([x,y,z])
        if line.startswith('TER'):
            coorddic[resnr] = []
            for c in coords:
                coorddic[resnr].append(np.average(c, axis=0))
            coords = [[],[],[]]
        elif line.startswith('CONECT'):
            coorddic[resnr] = []
            for c in coords:
                coorddic[resnr].append(np.average(c, axis=0))
            coords = [[],[],[]]
            break

def make_output():
    i=1
    c=1
    startresnr=1
    resnr=startresnr
    oper = cycle([1,3])
    new_lines = []
    for item in beaddic:
        for b in range(len(beaddic[item])):
            bead = beaddic[item][b]
            nline = "{:6s}{:5d} {:^4s}{:1s}{:3s}{:1s}{:3d}{:1s}   {:8.3f}{:8.3f}{:8.3f}{:6.2f}{:6.2f}      {:>2s}{:2s}".format('ATOM',i, bead,' ', 'BNAGX', '', resnr,'', \
                                                                                                                                                coorddic[item][b][0],coorddic[item][b][1], coorddic[item][b][2],\
                                                                                                                                                1.00, 0.00,'','')
            new_lines.append(nline+'\n')
            i+=1
        c+=1
        if c>20:
            c=1
            startresnr += 40
            resnr=startresnr
            
        else:
            resnr += next(oper)
        

    with open(outfile, 'w') as f:
        for line in new_lines:
            f.write(line)

                        
                
make_ichains()
make_jchains()
make_more_jchains()
make_corrddic()
make_output()
