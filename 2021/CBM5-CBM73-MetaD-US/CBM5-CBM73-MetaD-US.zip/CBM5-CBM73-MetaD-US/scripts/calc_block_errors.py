#!/lindorffgrp-isilon/courtade/software/my-envs/py37/bin/python

import sys
import numpy
import block
import os


def power2_compatible(a):                             
  log2_len_a=numpy.log(len(a))/numpy.log(2)
  log2_len_sub_a=int(numpy.floor(log2_len_a))
  len_sub_a=2**log2_len_sub_a
  return len_sub_a,a[:len_sub_a],a[len(a)-len_sub_a:]

result = []
file='COORDINATION'
weights = numpy.loadtxt('bias',usecols=1)
weights /= numpy.sum(weights)

nrcols=int(os.popen("awk -F' ' '{print NF; exit}' COORDINATION").read())-3

for col in range(1,nrcols+1):
  x = numpy.loadtxt(file,usecols=col)
  mean = numpy.sum(x*weights)
#  mean=x.mean()
  var_bias=x.var()
  var_unbias=var_bias*len(x)/(len(x)-1.0)
  stddev=numpy.sqrt(var_unbias)
  stderr=stddev/numpy.sqrt(len(x))
  
  n,x_first,x_last=power2_compatible(x)
  
  b_first=block.BlockSample(x_first)
  stderr_block_first=b_first.std_error()
  
  b_last=block.BlockSample(x_last)
  stderr_block_last=b_last.std_error()
  
  
  stderr_block=0.5*(stderr_block_first+stderr_block_last)
  stderr_block_extrapolated=stderr_block*numpy.sqrt(float(n)/float(len(x)))
  result.append([col,mean,stderr_block_extrapolated])
  
  numpy.savetxt('coordination_block_errors.txt',result)





        

