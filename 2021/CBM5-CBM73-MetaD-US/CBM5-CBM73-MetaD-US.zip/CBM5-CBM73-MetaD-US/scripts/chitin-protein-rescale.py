#
# Rescale chitin-protein interactions
# in martini_v3.0.4_chitin.itp
# Chitin beads: BC1, PC1,TH1,BC2, PC2,TH2
#
# G. Courtade - 05.04.20
#

import sys

filename = sys.argv[1]
theta = float(sys.argv[2])
outfile = sys.argv[3]

with open(filename, 'r') as f:
	lines = f.readlines()

chitin_beads = ['BC1', 'PC1','TH1','BC2', 'PC2','TH2']
water_beads = ['W', 'TW', 'SW']
nlines = []

for line in lines:
	counti=0
	countj=0
	lsplit = line.split()
	if len(lsplit)==5:
		for i in chitin_beads:
			counti += lsplit.count(i)

		# only change if one of the beads is a chitin bead
		if counti==1:
			for j in water_beads:
				countj += lsplit.count(j)

			# only change if there is no water beads
			if countj==0:
				lsplit[3] = '{:.6e}'.format((float(lsplit[3])*theta))
				lsplit[4] = '{:.6e}'.format((float(lsplit[4])*theta))
				nlines.append('\t'.join(lsplit) + f' ; changed this interaction by {theta} \n')
			else:
				nlines.append('\t'.join(lsplit) + ' ; unchanged \n')
		else:
			nlines.append('\t'.join(lsplit) + ' ; unchanged \n')
	else:
		nlines.append(line)



with open(outfile, 'w') as f:
	for nl in nlines:
		f.write(nl)


